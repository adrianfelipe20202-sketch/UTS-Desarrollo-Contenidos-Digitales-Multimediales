# ACTIVIDAD SEMANA 9

Proyecto Unity 3D para la Actividad de la Semana 9 del curso de Programacion de Videojuegos.

## Version de Unity

**Unity 2022.3.62f3** (LTS)

Requiere esta version exacta o compatible dentro del ciclo 2022.3 LTS.

## Como abrir el proyecto

1. Clonar el repositorio:
   ```
   git clone <url-del-repo>
   ```
2. Abrir **Unity Hub**.
3. Click en **Add** -> seleccionar la carpeta `ACTIVIDADSEMANA9`.
4. Asegurarse de tener instalado **Unity 2022.3.62f3** (o instalarlo desde Unity Hub).
5. Abrir el proyecto. Unity regenerara automaticamente las carpetas `Library/`, `Temp/` y `obj/` en el primer arranque (puede tardar unos minutos).
6. Abrir la escena desde `Assets/Scenes/SampleScene.unity` o `Assets/Scenes/Nivel2.unity`.
7. Presionar **Play**.

## Estructura

- `Assets/Scripts/` — Scripts C# del juego (POO: herencia, polimorfismo).
- `Assets/Scenes/` — Escenas del proyecto.
- `Assets/Materials/` — Materiales.
- `Assets/Prefabs/` — Prefabs.
- `ProjectSettings/` — Configuracion del proyecto (no modificar).
- `Packages/` — Dependencias de Unity Package Manager.
