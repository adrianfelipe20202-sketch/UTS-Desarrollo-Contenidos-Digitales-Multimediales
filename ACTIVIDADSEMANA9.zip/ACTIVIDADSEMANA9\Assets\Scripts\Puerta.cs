using UnityEngine;
using UnityEngine.SceneManagement;

public class Puerta : ObjetoInteractivo
{
    private bool _abierta  = false;
    private bool _cargando = false;

    private void Start()
    {
        textoIndicador = "Presiona E para abrir la puerta";
    }

    public override void Interactuar()
    {
        if (_cargando) return;

        if (GestorJuego.cofreAbierto)
        {
            _cargando = true;
            ContadorItems.MostrarMensajeTemporal("¡FELICIDADES! Cargando Nivel 2...", 3f);
            Invoke(nameof(CargarNivel2), 1.5f);
            return;
        }

        _abierta = !_abierta;
        transform.Rotate(0f, _abierta ? 90f : -90f, 0f);
    }

    void CargarNivel2()
    {
        GestorJuego.Reiniciar();
        // Carga por índice — siempre funciona si Build Settings está correcto
        int indiceActual = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(indiceActual + 1);
    }
}
