using UnityEngine;

// Encapsulacion: los datos del jugador son privados
// y se accede a ellos mediante propiedades publicas
public class Jugador : MonoBehaviour
{
    [Header("Estadisticas")]
    [SerializeField] private float _velocidad = 5f;
    [SerializeField] private int _vida = 100;
    [SerializeField] private int _vidaMaxima = 100;

    public float Velocidad
    {
        get { return _velocidad; }
        private set { _velocidad = Mathf.Max(0, value); }
    }

    public int Vida
    {
        get { return _vida; }
        private set { _vida = Mathf.Clamp(value, 0, _vidaMaxima); }
    }

    public bool EstaVivo => _vida > 0;

    private CharacterController _controller;

    private void Awake()
    {
        _controller = GetComponent<CharacterController>();
    }

    private void Update()
    {
        if (!EstaVivo) return;
        Mover();
    }

    private void Mover()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        Vector3 direccion = new Vector3(horizontal, 0f, vertical).normalized;
        if (direccion.magnitude >= 0.1f)
        {
            _controller.Move(direccion * _velocidad * Time.deltaTime);
        }
    }

    public void RecibirDanio(int cantidad)
    {
        Vida -= cantidad;
        Debug.Log($"Jugador recibio {cantidad} de danio. Vida restante: {Vida}");

        if (!EstaVivo)
        {
            Debug.Log("El jugador ha muerto");
        }
    }

    public void Curar(int cantidad)
    {
        Vida += cantidad;
        Debug.Log($"Jugador curado por {cantidad}. Vida actual: {Vida}");
    }
}
