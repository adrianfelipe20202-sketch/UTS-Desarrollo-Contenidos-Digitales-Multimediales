using UnityEngine;

public class Enemigo : MonoBehaviour
{
    [Header("Estadisticas")]
    [SerializeField] private int _danio = 10;
    [SerializeField] private float _velocidad = 2f;

    private Transform _objetivoJugador;

    private void Start()
    {
        GameObject jugadorObj = GameObject.FindGameObjectWithTag("Player");
        if (jugadorObj != null)
        {
            _objetivoJugador = jugadorObj.transform;
        }
    }

    private void Update()
    {
        if (_objetivoJugador == null) return;

        Vector3 direccion = (_objetivoJugador.position - transform.position).normalized;
        transform.position += direccion * _velocidad * Time.deltaTime;
        transform.LookAt(_objetivoJugador);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Jugador jugador = collision.gameObject.GetComponent<Jugador>();
            if (jugador != null)
            {
                jugador.RecibirDanio(_danio);
            }
        }
    }
}
