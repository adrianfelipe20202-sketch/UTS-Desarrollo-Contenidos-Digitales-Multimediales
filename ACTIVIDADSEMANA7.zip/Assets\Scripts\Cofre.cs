using UnityEngine;

public class Cofre : ObjetoInteractivo
{
    private bool _abierto = false;

    public override void Interactuar()
    {
        if (_abierto)
        {
            Debug.Log("El cofre ya esta vacio");
            return;
        }

        _abierto = true;
        Debug.Log("Has obtenido un objeto del cofre");
    }
}
