using UnityEngine;

public class Puerta : ObjetoInteractivo
{
    private bool _abierta = false;

    public override void Interactuar()
    {
        _abierta = !_abierta;
        if (_abierta)
        {
            Debug.Log("La puerta se abre");
            transform.Rotate(0, 90, 0);
        }
        else
        {
            Debug.Log("La puerta se cierra");
            transform.Rotate(0, -90, 0);
        }
    }
}
